<?php
/**
 +------------------------------------------------------------------------------
 * MagazineAction控制器类
 +------------------------------------------------------------------------------
 * @category   SubAction
 * @package  app
 * @subpackage  Action
 * @author   朝闻道 <hydata@gmail.com>
 * @date 2010-5-11
 * @time  上午10:42:16
 +------------------------------------------------------------------------------
 */
class MagazineAction extends CommonAction{
	
}//end MagazineAction