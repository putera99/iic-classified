<?php
class AddonJobsModel extends Model{


}
?>