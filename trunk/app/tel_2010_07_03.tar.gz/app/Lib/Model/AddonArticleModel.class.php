<?php
class AddonArticleModel extends Model{


}
?>