<?php
class MtagCatModel extends Model {
	
}
?>