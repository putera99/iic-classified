<?php
/**
 +------------------------------------------------------------------------------
 * ArctypeModel 数据对象映射类
 +------------------------------------------------------------------------------
 * @category   SubModel
 * @package  app
 * @subpackage  Model
 * @author   朝闻道 <hydata@gmail.com>
 * @date 2010-4-29
 * @time  上午10:17:12
 +------------------------------------------------------------------------------
 */
class ArctypeModel extends Model{
	
}//end ArctypeModel