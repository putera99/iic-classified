<?php
/**
 +------------------------------------------------------------------------------
 * TagspaceModel 数据对象映射类
 +------------------------------------------------------------------------------
 * @category   SubModel
 * @package  app
 * @subpackage  Model
 * @author   朝闻道 <hydata@gmail.com>
 * @date 2010-6-7
 * @time  下午09:08:19
 +------------------------------------------------------------------------------
 */
class TagspaceModel extends Model{
	protected $_auto=array(
	);
}//end TagspaceModel