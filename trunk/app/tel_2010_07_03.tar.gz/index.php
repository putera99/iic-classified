<?php
define('THINK_PATH', './Inc');
define('APP_NAME', 'app');
define('APP_PATH', './app');
require(THINK_PATH."/ThinkPHP.php");
App::run();
?>